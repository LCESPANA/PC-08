﻿using System.ComponentModel;
using System.Linq.Expressions;

class Semana9_actividad1 
{
  static void Main(string [] args)
    {
        string entrada;
        int numero;


        
        
        while (true)
        {
         Console.WriteLine($"ingrese un numero entero positivo, menor o igual a 6 cifras");
         entrada = Console.ReadLine();
 
            if (int.TryParse(entrada, out numero))
            {
                if (numero > 0 && numero < 999999)
                {
                    break;
                }
                else 
                {
                    Console.WriteLine("Numero invalido debe ser positivo menor a 7 cifras");
                }
            }
            else
            {
                Console.WriteLine("Entrada invalida, debe ser un numero");
            }
        }

       if ( (numero % 2) == 0 || (numero % 3) == 0 || (numero % 5) == 0 || (numero % 7) == 0 )
       {
         if (numero == 1 || numero == 2 || numero == 3 || numero == 5 || numero == 7)
            {
                Console.WriteLine($"El numero ingresado ({numero}) es un numero primo");

            }
            else 
            {
                Console.WriteLine($"El numero ingresado ({numero}) no es un numero primo");
            }

       }
       else 
       {
        Console.WriteLine($"El numero ingresado({numero}) es un numero primo");
       }

        


    }

 
}
    
       
            

