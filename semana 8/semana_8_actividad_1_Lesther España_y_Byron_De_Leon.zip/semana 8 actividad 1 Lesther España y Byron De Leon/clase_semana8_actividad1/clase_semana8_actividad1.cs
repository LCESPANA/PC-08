﻿class clase_semana8_actividad1
{
        static void Main()
        {
            System.Console.WriteLine($"FACOTRIAL");
            System.Console.WriteLine();
            int numero;
            while (true)
            {
                string entrada;
                
            Console.Write($"Ingrese un número: ");
            entrada = Console.ReadLine();
 
            if (int.TryParse(entrada, out numero))
            {
                break;
            }
            else
            {
                Console.WriteLine($"Entrada inválida. Inténtalo de nuevo.");
            }
            }
            
            while (true)
            {
        
            if (numero>=0)
            {   
                break;
            }
            else
            {   System.Console.WriteLine($"DEBE SER MAYOR A CERO, INGRESE NUEVAMENTE EL NUMERO");
                numero=int.Parse(Console.ReadLine());
                
                
            }
            }
            Console.WriteLine(calcularFactorial(numero));
            /*
            if (numero<0)
            {
                System.Console.WriteLine("DEBE SER MAYOR A CERO");
            }else
            {
                Console.WriteLine(calcularFactorial(numero));
            }*/
        }

    static int calcularFactorial(int numero)

    {   

        if (numero == 0)

        {       

            return 1;

        }

        else    

        {

            int factorial = 1;

                for (int i = 1; i <= numero; i++)

                {
                    factorial *= i;
                }

        return factorial;

        }

    }

}