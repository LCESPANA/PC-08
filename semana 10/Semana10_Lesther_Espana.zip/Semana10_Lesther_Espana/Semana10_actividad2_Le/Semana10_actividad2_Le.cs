﻿class Semana10_actividad2_Le
{
    static void Main()
    {
        int[] numeros = new int[8];
        string entrada; 
        int suma = 0;
        int j;
        for ( j = 0 ; j < 8; j++ ) 
        while (true)
        {
            Console.Write($"Ingrese 8 datos numericos No. de dato {8 - j} ");
            entrada = Console.ReadLine();
 
            if (int.TryParse(entrada, out numeros [j]))
            {
                suma += numeros[j];
                break; 
            }
            else
            {
                Console.WriteLine("Entrada inválida. Inténtalo de nuevo.");
            }
        }
        Console.WriteLine($"Numeros ingresados");
        foreach (int numero in numeros)
        {
            
            Console.Write($"\t{numero}  ");

        }
        
        
        Console.WriteLine($"sumatoria de numeros = {suma}");
        Console.WriteLine($"Promedio de los numeros ingresados {(double)suma / numeros.Length}");
        
        
    
    }
}

    
