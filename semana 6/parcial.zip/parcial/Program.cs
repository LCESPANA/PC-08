﻿class Program
{
    static void Main(String[] args)
    {
        Console.WriteLine("ingrese un numero del 0 al 99");
        int x = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("ingrese un numero del 0 al 99");
        int y = Convert.ToInt32(Console.ReadLine());
        
        Console.WriteLine("ingrese un numero del 0 al 99");
        int z = Convert.ToInt32(Console.ReadLine());
        

        if (x>y)
        Console.WriteLine("el numero mayor es el numero 1 " + x);
        else Console.WriteLine("el numero mayor es numero 2 " + y);

        if (x<y)
        Console.WriteLine("el numero menor es el numero 1 " + x);
        else Console.WriteLine("el numero menor es el numero 2 " + y);
        
         if (x>z)
        Console.WriteLine("el numero mayor es el numero 1 " + x);
        else Console.WriteLine("el numero mayor es el numero 3 " + z);

        if (x<z)
        Console.WriteLine("el numero menor es el numero 1 " + x);
        else Console.WriteLine("el numero menor es el numero 3 " + z);

         if (y>z)
        Console.WriteLine("el numero mayor es el numero 2 " + y);
        else Console.WriteLine("el numero mayor es numero 3 " + z);

        if (y<z)
        Console.WriteLine("el numero menor es el numero 2 " + y);
        else Console.WriteLine("el numero menor es el numero 3 " + z);
    }
}